/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog6112_assignment01_kiarasingh_st10215222_question02_;

/**
 *
 * @author lab_services_student
 */
public class Product {
    
    private String name;
    private double price;
    private int quantity;

    public Product(String name, double price, int quantity) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }
    
    public void addQuantity(int quantityToAdd) {
        this.quantity += quantityToAdd;
    }

    public void removeQuantity(int quantityToRemove) {
        if (quantityToRemove <= quantity) {
            this.quantity -= quantityToRemove;
        } else {
            System.out.println("Not enough quantity available.");
        }
    }
    
}
