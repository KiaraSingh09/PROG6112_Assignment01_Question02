/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog6112_assignment01_kiarasingh_st10215222_question02_;

/**
 *
 * @author lab_services_student
 */
public class Inventory {
    
    private Product[] products;
    private int numProducts;

    public int getNumProducts() {
        return numProducts;
    }

    public Inventory(int capacity) {
        products = new Product[capacity];
        numProducts = 0;
    }

    public void addProduct(String name, double price, int quantity) {
        if (numProducts < products.length) {
            Product newProduct = new Product(name, price, quantity);
            products[numProducts] = newProduct;
            numProducts++;
            System.out.println("Product added successfully.");
        } else {
            System.out.println("Inventory is full. Cannot add more products.");
        }
    }

    public void removeProduct(String name) {
        for (int i = 0; i < numProducts; i++) {
            if (products[i].getName().equalsIgnoreCase(name)) {
                for (int j = i; j < numProducts - 1; j++) {
                    products[j] = products[j + 1];
                }
                numProducts--;
                System.out.println("Product removed successfully.");
                return;
            }
        }
        System.out.println("Product with name '" + name + "' not found.");
    }

    public void listProducts() {
        if (numProducts == 0) {
            System.out.println("Inventory is empty.");
            return;
        }

        System.out.println("List of Products:");
        for (int i = 0; i < numProducts; i++) {
            Product product = products[i];
            System.out.println("Name: " + product.getName());
            System.out.println("Price: R" + product.getPrice());
            System.out.println("Quantity: " + product.getQuantity());
            System.out.println("-----------------------");
        }
    }
    
}
