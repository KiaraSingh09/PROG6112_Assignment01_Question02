/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prog6112_assignment01_kiarasingh_st10215222_question02_;

import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class PROG6112_Assignment01_KiaraSingh_ST10215222_Question02_ {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        Scanner scanner = new Scanner(System.in);
        Inventory inventory = new Inventory(10);

        while (true) {
            System.out.println("Inventory Management System Menu:");
            System.out.println("1. Add a Product");
            System.out.println("2. Remove a Product");
            System.out.println("3. List all Products");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Product Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Product Price: R");
                    double price = scanner.nextDouble();
                    System.out.print("Enter Product Quantity: ");
                    int quantity = scanner.nextInt();
                    inventory.addProduct(name, price, quantity);
                    break;
                case 2:
                    System.out.print("Enter the name of the product to remove: ");
                    name = scanner.nextLine();
                    inventory.removeProduct(name);
                    break;
                case 3:
                    inventory.listProducts();
                    break;
                case 4:
                    System.out.println("Exiting Inventory Management System. Goodbye!");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }
    
}
