/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package prog6112_assignment01_kiarasingh_st10215222_question02_;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

/**
 *
 * @author lab_services_student
 */
public class PROG6112_Assignment01_KiaraSingh_ST10215222_Question02_Test {
    
    public PROG6112_Assignment01_KiaraSingh_ST10215222_Question02_Test() {
    }

   private Inventory inventory;

    @Before
    public void setUp() {
        // Create a new Inventory before each test
        inventory = new Inventory(10);
    }

    @Test
    public void testAddProduct() {
        inventory.addProduct("TestProduct", 10.0, 5);
        assertEquals(1, inventory.getNumProducts());
    }

    @Test
    public void testRemoveProduct() {
        // Add a product first
        inventory.addProduct("TestProduct", 10.0, 5);
        
        // Remove the product
        inventory.removeProduct("TestProduct");
        assertEquals(0, inventory.getNumProducts());
    }

    @Test
    public void testListProducts() {
        // Add some products
        inventory.addProduct("Product1", 10.0, 5);
        inventory.addProduct("Product2", 20.0, 3);
        
        // Capture the console output
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        
        // Call listProducts method
        inventory.listProducts();
        
        // Verify the output
        String expectedOutput = "List of Products:\n" +
                "Name: Product1\n" +
                "Price: R10.0\n" +
                "Quantity: 5\n" +
                "-----------------------\n" +
                "Name: Product2\n" +
                "Price: R20.0\n" +
                "Quantity: 3\n" +
                "-----------------------\n";
        assertEquals(expectedOutput, outContent.toString());
    }
    
}
